
  /genesis/images
  
    Core theme icons, screenshot and the legend sprite.
    
    The legend-sprite is a CSS sprite for the collaspible fieldset arrows.
    - legend-sprite.gif
    
    The icons are for Drupal messages, you can replace with your own set:
    - error.png (Gnome)
    - info.png (Custom)
    - ok.png (copied from Drupal core)
    - warning.png (Gnome)
    - warning-small.png (Gnome)
    - help.png: standard Gnome help icon (not used in the theme)

    Also includes the gridtile which you can use to display a vertical grid
    for text alignment. To enable the vertical grid add the class "grid" to
    the #container div in page.tpl.php and uncomment the grid.css file in
    genesis.info.
    - gridtile.gif
  
    
    OpenID Icon: this is included because Genesis overrites the OpenID modules
    CSS in order to correct the icon positioning errors.
    - openid.png
  
  
  /genesis/images/fireworks
  
    Genesis uses two CSS sprites - one for the legend arrows and another for
    menu bullets and arrows. You will find the menu sprite in your subthemes
    images folder.
    
    The fireworks versions are fireworks.png format and are fully editable.
    
    
    
    