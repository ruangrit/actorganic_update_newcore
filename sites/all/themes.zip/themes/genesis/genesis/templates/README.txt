  
  This directory contains back-up copies of all the subthemes template files.
  
  The backups can be usefull if:
  
  - you make a mistake and need to restore the original file.
  - you make changes but need a copy of the original for a template suggestion.