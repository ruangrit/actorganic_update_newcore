  
  /genesis_DARK/CSS
  
  This directory contains the genesis_DARK CSS files.
  
  /ie/ie-example.css
    An empty IE stylesheet to support the Conditional Styles module. 
    This module allows themes to specify conditional stylesheets in 
    their info file and the conditional comments will be automatically 
    included at the end of the standard $styles variable. 
    
    Note: You do not need to install the module, it is included inGenesis.
 
    Uncomment or add the required stylesheets in your subthemes .info file.
    
    
  _all-dark-tidy.css
    The is a copy of _all-dark.css but with all the empty selectors
    and comments removed. Use this if you only want a very basic
    starter CSS file. See your subthemes .info file for instructions
    on how to enable the use of this stylesheet.
  
  _all-dark.css
    The all-dark stylesheet is all the modular stylesheets aggreated
    into one. Use this if you run into Internet Explorer's max 30
    stylesheet issue or if you need to reduce http requests and cannot
    use the CSS aggregation and compression feature of Drupal 6.
    See your subthemes .info file for instructions on how to enable 
    the use of this stylesheet.
    
  blocks.css
    All classes for theming comments, including many extra classes 
    such as #block-book-0, #block-blog-0, #block-comment-0 and so on.
    
  comments.css
    All classes for theming comments, including many extra classes 
    such as .comment-by-anonymous, .comment-by-node-author etc.
    
  node.css
    All classes for theming nodes, including many extra classes 
    such as .node-sticky, .node-promoted, node type classes and 
    class for theming fields such as .field-type-image. These are
    just a sample, there are many more.
  
  page.css
    This stylesheet provides the main page styles for this theme,
    such as section, page and body classes, regions, sidebars, header,
    footer, primary and secondary links, breadcrumbs and so on.
 
  style_dark.css
    Contains overrides to support dark style themes. Overrides 
    Drupal core and the core Genesis styles. Includes basic support
    for Views, Panels and Verical tabs modules.

  styles.css
    Use this file to override the Genesis core modular styles 
    (such as the HTML elements in typography.css), module CSS 
    and other Drupal styles. Anything that doesn't fit logically
    into page.css, nodes.css, blocks.css or comments.css can go here.
    
    
    

    