; $Id: README.txt,v 1.2 2009/11/06 16:00:43 mcrittenden Exp $

This theme is just a backport of the Drupal 7 admin theme (designed by Mark and Leisa).

The only changes are small API changes between Drupal 6 and 7 for compatibility.

Please post any issues to the issue queue at http://drupal.org/project/issues/seven

