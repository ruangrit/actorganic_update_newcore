<?php

$body_settings = $view->display['default']->display_options['fields']['body'];
if ($body_settings['alter']['trim']) {
  if ($body_settings['alter']['strip_tags']) {
    $output = strip_tags($output);
  }
  $output = truncate_utf8($output, $body_settings['alter']['max_length'], $body_settings['alter']['word_boundary'], $body_settings['alter']['ellipsis']);
}
print $output;
